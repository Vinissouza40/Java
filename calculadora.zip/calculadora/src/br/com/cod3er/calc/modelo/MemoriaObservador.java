package br.com.cod3er.calc.modelo;
@FunctionalInterface
public interface MemoriaObservador {
	
 public void valorAlterado(String novoValor);
 	
}
