package br.com.cod3er.cm.modelo;

public enum CampoEvento {
	ABRIR, MARCAR, DESMARCAR, EXPLODIR, REINICIAR
	
}
