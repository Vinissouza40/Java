package br.com.cod3er.cm.modelo;

public interface CampoObservador {
	public void eventoOcorreu(Campo campo, CampoEvento evento);
	
}
